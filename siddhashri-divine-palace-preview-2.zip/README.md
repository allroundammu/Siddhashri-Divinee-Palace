# Siddhashri Divine Palace — React preview

A frontend-only visual preview for Siddhashri Divine Palace, Kalaburagi. It intentionally uses only the facts supplied in the brief:

- Functions up to 5,000 people
- Vast dining hall
- 2-acre parking space
- Weddings, receptions, engagements, birthdays, cradle ceremonies, baby showers and other family celebrations
- Kalaburagi, Karnataka; public listings indicate the Kotnoor / Oza Layout vicinity, pending owner confirmation

## Run locally

```bash
npm install
npm run dev -- --host 0.0.0.0 --port 5173
```

The enquiry form is a frontend preview only. The production build can connect it to a Neon PostgreSQL API after owner-approved phone, WhatsApp, email, exact address/map pin, policies, current specifications and genuine venue photographs are collected.
