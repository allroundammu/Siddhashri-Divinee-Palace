import { useState } from 'react'

const eventTypes = [
  { number: '01', title: 'Weddings & receptions', text: 'A spacious setting for the day your families have been waiting for.', icon: '✦' },
  { number: '02', title: 'Engagements', text: 'A considered venue for the first celebration of a new chapter.', icon: '◌' },
  { number: '03', title: 'Birthdays', text: 'Bring loved ones together for joyful family moments.', icon: '✺' },
  { number: '04', title: 'Cradle ceremonies & baby showers', text: 'Warm, meaningful gatherings for life’s tender milestones.', icon: '⌁' },
  { number: '05', title: 'Other family celebrations', text: 'Anniversaries, naming ceremonies and gatherings shaped around your family.', icon: '◇' },
]

const faqs = [
  ['How many people can the venue accommodate?', 'Siddhashri Divine Palace can accommodate functions for up to 5,000 people. The suitable arrangement depends on your event format and guest count, so share your requirements with the venue team.'],
  ['What types of functions can be held here?', 'The venue is intended for birthdays, engagements, weddings, wedding receptions, cradle ceremonies, baby showers and other family celebrations.'],
  ['Is parking available?', 'The venue has a 2-acre parking space. Please ask the venue team about the current access and parking arrangement for your preferred event date.'],
  ['Can I check availability online?', 'This preview does not claim live availability. Send your preferred date and function details through the enquiry form so the venue team can respond.'],
]

function Arrow() {
  return <span aria-hidden="true" className="arrow">↗</span>
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [openFaq, setOpenFaq] = useState(0)

  const closeMenu = () => setMenuOpen(false)

  const handleSubmit = (event) => {
    event.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="site-shell">
      <div className="announcement">
        <div className="container announcement-inner">
          <span className="announcement-mark">SDP</span>
          <span>Function hall in Kalaburagi for life’s most meaningful gatherings</span>
          <a href="#enquire">Plan your function <Arrow /></a>
        </div>
      </div>

      <header className="site-header">
        <div className="container nav-wrap">
          <a className="brand" href="#top" onClick={closeMenu} aria-label="Siddhashri Divine Palace home">
            <span className="brand-symbol" aria-hidden="true"><span></span><span></span><span></span></span>
            <span className="brand-copy"><strong>Siddhashri</strong><small>Divine Palace</small></span>
          </a>
          <button className={`menu-toggle ${menuOpen ? 'is-open' : ''}`} onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation" aria-expanded={menuOpen}>
            <span></span><span></span><span></span>
          </button>
          <nav className={`main-nav ${menuOpen ? 'is-open' : ''}`} aria-label="Primary navigation">
            <a href="#occasions" onClick={closeMenu}>Occasions</a>
            <a href="#venue" onClick={closeMenu}>The venue</a>
            <a href="#gallery" onClick={closeMenu}>Gallery</a>
            <a href="#faqs" onClick={closeMenu}>FAQs</a>
            <a href="#enquire" className="nav-cta" onClick={closeMenu}>Enquire <Arrow /></a>
          </nav>
        </div>
      </header>

      <main id="top">
        <section className="hero">
          <div className="hero-grain"></div>
          <div className="container hero-grid">
            <div className="hero-copy">
              <p className="eyebrow"><span></span> Kalaburagi · Karnataka</p>
              <h1>A spacious place for <em>every family milestone.</em></h1>
              <p className="hero-lede">Siddhashri Divine Palace is a function hall for weddings, receptions, engagements, birthdays, cradle ceremonies, baby showers and celebrations that bring everyone together.</p>
              <div className="hero-actions">
                <a className="button button-gold" href="#enquire">Enquire about your function <Arrow /></a>
                <a className="text-link" href="#gallery">See the venue preview <span>↓</span></a>
              </div>
              <div className="hero-note"><span className="note-dot"></span> Owner-approved photographs will replace these preview panels before launch.</div>
            </div>
            <div className="hero-art" aria-label="Siddhashri Divine Palace exterior photograph">
              <div className="art-frame art-frame-photo">
                <img className="hero-photo" src="/images/function-hall.jpg" alt="Illuminated exterior of Siddhashri Divine Palace function hall in Kalaburagi" />
                <div className="photo-shade"></div>
                <div className="art-topline"><span>01</span><span>Venue portrait · supplied photo</span></div>
                <div className="art-caption"><span className="caption-line"></span><span>Actual Siddhashri Divine Palace exterior</span></div>
              </div>
              <div className="art-vertical">A PLACE TO GATHER · KALABURAGI</div>
            </div>
          </div>
          <div className="hero-scroll"><span>Scroll to explore</span><i></i></div>
        </section>

        <section className="proof-strip" aria-label="Venue highlights">
          <div className="container proof-grid">
            <div className="proof-intro"><span className="mini-label">At a glance</span><strong>Make room for<br /><em>everyone.</em></strong></div>
            <div className="proof-stat"><b>5,000</b><span>people for functions<br />up to this scale</span></div>
            <div className="proof-stat"><b>2 acres</b><span>of parking space<br />for guest convenience</span></div>
            <div className="proof-stat"><b>01</b><span>vast dining hall<br />for shared moments</span></div>
          </div>
        </section>

        <section className="section occasions" id="occasions">
          <div className="container">
            <div className="section-heading split-heading">
              <div><span className="section-kicker">A venue for your occasion</span><h2>From the first <em>yes</em><br />to every toast after.</h2></div>
              <p>One place, many reasons to come together. Start with the celebration you are planning and tell us what your day needs.</p>
            </div>
            <div className="occasion-list">
              {eventTypes.map((item) => (
                <a className="occasion-row" href="#enquire" key={item.number}>
                  <span className="occasion-number">{item.number}</span>
                  <span className="occasion-icon" aria-hidden="true">{item.icon}</span>
                  <span className="occasion-main"><strong>{item.title}</strong><small>{item.text}</small></span>
                  <Arrow />
                </a>
              ))}
            </div>
          </div>
        </section>

        <section className="section venue-section" id="venue">
          <div className="container venue-grid">
            <div className="venue-visual">
              <div className="visual-card dining-card"><span className="visual-index">02 / 03</span><span className="visual-placeholder">Dining hall<br />photograph</span><small>Owner asset needed</small></div>
              <div className="visual-card parking-card"><span className="visual-index">03 / 03</span><span className="visual-placeholder">Parking space<br />photograph</span><small>Owner asset needed</small></div>
              <div className="visual-stamp">YOUR<br /><em>day</em><br />belongs<br />here</div>
            </div>
            <div className="venue-copy">
              <span className="section-kicker">The details that matter</span>
              <h2>Room for the moment.<br /><em>Space for the people.</em></h2>
              <p className="lead">Planning a large celebration means thinking beyond the stage. It means considering where guests arrive, gather, dine and feel at ease.</p>
              <div className="detail-list">
                <div><span className="detail-icon">01</span><div><strong>Up to 5,000 people</strong><p>Suitable for large gatherings, with the final arrangement shaped around your function.</p></div></div>
                <div><span className="detail-icon">02</span><div><strong>A vast dining hall</strong><p>A dedicated space for the shared meals and conversations that make celebrations memorable.</p></div></div>
                <div><span className="detail-icon">03</span><div><strong>2-acre parking space</strong><p>Generous parking space designed to support guest convenience on important days.</p></div></div>
              </div>
              <a href="#enquire" className="underlined-link">Ask about your event requirements <Arrow /></a>
            </div>
          </div>
        </section>

        <section className="section gallery-section" id="gallery">
          <div className="container">
            <div className="section-heading gallery-heading"><div><span className="section-kicker">A real view matters</span><h2>See the place<br /><em>before you decide.</em></h2></div><p>This gallery is structured for genuine photographs of Siddhashri Divine Palace — not stock palace imagery. The final site will show the exterior, hall, event setups, dining hall and parking with accurate captions.</p></div>
            <div className="gallery-grid">
              <div className="gallery-tile tile-large"><span className="tile-label">Exterior & entrance</span><strong>Owner photograph<br />to be added</strong><span className="tile-foot">16:9 recommended</span></div>
              <div className="gallery-tile tile-tall"><span className="tile-label">Main function hall</span><strong>Owner photograph<br />to be added</strong><span className="tile-foot">4:5 recommended</span></div>
              <div className="gallery-tile tile-small"><span className="tile-label">A real event</span><strong>With consent</strong><span className="tile-foot">4:3 recommended</span></div>
              <div className="gallery-tile tile-small alt"><span className="tile-label">Dining hall</span><strong>Owner photograph<br />to be added</strong><span className="tile-foot">4:3 recommended</span></div>
            </div>
            <p className="gallery-disclaimer"><span>✦</span> The visual direction is ready. We need current, high-quality, owner-approved photographs to make this section true to the venue.</p>
          </div>
        </section>

        <section className="visit-band">
          <div className="container visit-grid">
            <div><span className="section-kicker">Find your way here</span><h2>Planning starts with<br /><em>a conversation.</em></h2></div>
            <div className="visit-copy"><p>Siddhashri Divine Palace is in Kalaburagi, Karnataka, in the Kotnoor / Oza Layout vicinity according to public listings. The exact address, map pin and landmark details should be confirmed by the venue before launch.</p><a className="button button-outline" href="#enquire">Request directions & availability <Arrow /></a></div>
          </div>
        </section>

        <section className="section faq-section" id="faqs">
          <div className="container faq-grid">
            <div><span className="section-kicker">Questions, answered carefully</span><h2>Clarity makes<br /><em>planning lighter.</em></h2><p className="faq-intro">These answers use only the information currently confirmed. The final website can expand this section once the venue owner approves the remaining details.</p><a className="underlined-link" href="#enquire">Have another question? Ask us <Arrow /></a></div>
            <div className="faq-list">{faqs.map(([question, answer], index) => <div className={`faq-item ${openFaq === index ? 'open' : ''}`} key={question}><button onClick={() => setOpenFaq(openFaq === index ? -1 : index)} aria-expanded={openFaq === index}><span>{question}</span><b>{openFaq === index ? '−' : '+'}</b></button><div className="faq-answer"><p>{answer}</p></div></div>)}</div>
          </div>
        </section>

        <section className="enquire-section" id="enquire">
          <div className="container enquire-grid">
            <div className="enquire-intro"><span className="section-kicker">Tell us about your day</span><h2>Let’s plan a gathering that feels <em>like yours.</em></h2><p>Share the basics and the venue team can respond with the next steps. This preview does not claim live availability or confirmed pricing.</p><div className="contact-placeholder"><span className="contact-symbol">✦</span><div><strong>Direct contact details to be added</strong><small>Phone, WhatsApp and email will appear here after owner confirmation.</small></div></div></div>
            <div className="form-panel">
              {!submitted ? <form onSubmit={handleSubmit}><div className="form-row"><label>Name<input required name="name" placeholder="Your name" /></label><label>Phone<input required name="phone" placeholder="Your phone number" /></label></div><div className="form-row"><label>Function type<select required name="function"><option value="">Select an occasion</option><option>Wedding or reception</option><option>Engagement</option><option>Birthday</option><option>Cradle or naming ceremony</option><option>Baby shower</option><option>Other family celebration</option></select></label><label>Preferred date<input type="date" name="date" /></label></div><label>Estimated guests<input type="number" min="1" name="guests" placeholder="Approximate guest count" /></label><label>Anything you would like to ask?<textarea name="message" rows="4" placeholder="Tell us a little about your function"></textarea></label><button className="button button-gold form-submit" type="submit">Send enquiry preview <Arrow /></button><small className="form-note">Front-end preview only. Neon database, owner notifications and consent copy will be connected in the production build.</small></form> : <div className="success-state"><span className="success-mark">✓</span><span className="section-kicker">Thank you</span><h3>Your enquiry preview is ready.</h3><p>The production version will connect this form to Neon and route the enquiry to the venue team. No data has been sent from this preview.</p><button className="underlined-link" type="button" onClick={() => setSubmitted(false)}>Submit another enquiry <Arrow /></button></div>}
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer"><div className="container footer-grid"><a className="brand footer-brand" href="#top"><span className="brand-symbol" aria-hidden="true"><span></span><span></span><span></span></span><span className="brand-copy"><strong>Siddhashri</strong><small>Divine Palace</small></span></a><div><span className="footer-label">Explore</span><a href="#occasions">Occasions</a><a href="#venue">The venue</a><a href="#gallery">Gallery</a></div><div><span className="footer-label">Plan</span><a href="#faqs">FAQs</a><a href="#enquire">Enquire</a><a href="#enquire">Request a visit</a></div><div className="footer-note"><span className="footer-label">Kalaburagi · Karnataka</span><p>A premium digital preview shaped around verified venue facts. Final content, photographs and contact details require owner approval.</p></div></div><div className="container footer-bottom"><span>© 2026 Siddhashri Divine Palace</span><span>Privacy policy · To be added before launch</span></div></footer>
    </div>
  )
}

export default App
